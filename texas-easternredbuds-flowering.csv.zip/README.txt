Exported at 2026-10-27T16:05:58Z

Query: has%5B%5D=photos&quality_grade=any&identifications=any&place_id=18&taxon_id=48502&term_id=12&term_value_id=13

Columns:
id: Unique, sequential identifier for the observation
uuid: Universally unique identifier for the observation. See https://datatracker.ietf.org/doc/html/rfc9562
observed_on: Normalized date of observation
time_observed_at: Normalized datetime of observation
user_id: Unique, sequential identifier for the observer
quality_grade: Quality grade of this observation. See Help section for details on what this means. See https://help.inaturalist.org/support/solutions/articles/151000169936
url: URL for the observation
image_url: URL for the first photo associated with the observation
num_identification_agreements: Number of identifications associated with taxa that match or are contained by the taxon from the observer's identification
num_identification_disagreements: Number of identifications associated with taxa that do not match and are not contained by the taxon from the observer's identification
captive_cultivated: Observation is of an organism that exists in the time and place it was observed because humans intended it to be then and there. For more, see https://help.inaturalist.org/support/solutions/articles/151000169932
latitude: Publicly visible latitude from the observation location
longitude: Publicly visible longitude from the observation location
positional_accuracy: Coordinate precision (yeah, yeah, accuracy != precision, poor choice of names)
public_positional_accuracy: Maximum horizontal positional uncertainty in meters; includes uncertainty added by coordinate obscuration
geoprivacy: Whether or not the observer has chosen to obscure or hide the coordinates. See https://help.inaturalist.org/support/solutions/articles/151000169938
coordinates_obscured: Whether or not the coordinates have been obscured, either because of geoprivacy or because of a threatened taxon
place_county_name: The name of the third-level administrative area that contains this observation's coordinates (e.g. a county in most parts of the United States)
place_state_name: The name of the second-level administrative area that contains this observation's coordinates (e.g. a state in most parts of the United States)
scientific_name: Scientific name of the observed taxon according to iNaturalist
common_name: Common or vernacular name of the observed taxon according to iNaturalist
taxon_id: Unique, sequential identifier for the observed taxon

For more information about column headers, see https://www.inaturalist.org/terminology

